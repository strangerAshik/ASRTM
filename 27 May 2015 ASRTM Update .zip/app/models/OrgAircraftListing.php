<?php

class OrgAircraftListing extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_aircraft_listings';
}