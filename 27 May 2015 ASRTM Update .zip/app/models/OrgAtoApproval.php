<?php

class OrgAtoApproval extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_ato_approvals';
}