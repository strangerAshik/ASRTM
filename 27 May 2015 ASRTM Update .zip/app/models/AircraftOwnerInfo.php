<?php

class AircraftOwnerInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_owner_info';
}