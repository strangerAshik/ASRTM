<?php

class OrgAmoApproval extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_amo_approvals';
}