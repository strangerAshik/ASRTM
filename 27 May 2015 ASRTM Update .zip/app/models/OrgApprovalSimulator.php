<?php

class OrgApprovalSimulator extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_approval_simulators';
}