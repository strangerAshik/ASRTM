<?php

class OrgAocApprovalRoute extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_aoc_approval_routes';
}