<?php

class OrgFlightOperationsApproval extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_flight_operation_Approvals';
}