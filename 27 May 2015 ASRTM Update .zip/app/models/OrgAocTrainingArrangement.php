<?php

class OrgAocTrainingArrangement extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_aoc_training_arrangement';
}