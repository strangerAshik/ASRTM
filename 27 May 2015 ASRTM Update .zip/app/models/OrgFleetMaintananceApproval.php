<?php

class OrgFleetMaintananceApproval extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_fleet_maintanance_approvals';
}