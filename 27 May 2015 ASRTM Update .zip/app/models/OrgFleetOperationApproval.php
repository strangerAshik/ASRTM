<?php

class OrgFleetOperationApproval extends \Eloquent {
	protected $fillable = [];
	protected $table ="org_fleet_operation_approvals";
}