<?php

class SCPrimaryInspection extends \Eloquent {
	protected $fillable = [];
	protected $table = 'sc_primary_inspection';
}