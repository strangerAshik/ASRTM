<?php

class SCFollowUp extends \Eloquent {
	protected $fillable = [];
	protected $table ='sc_follow_up';
}