<?php

class LibSupportingDocument extends \Eloquent {
	protected $fillable = [];
	protected $table ='lib_suporting_docs';
}