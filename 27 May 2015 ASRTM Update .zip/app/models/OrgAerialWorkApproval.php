<?php

class OrgAerialWorkApproval extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_aerial_work_approvals';
}