<?php

class OrgCertificate extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_certificates';
}