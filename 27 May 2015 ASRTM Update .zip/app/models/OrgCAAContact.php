<?php

class OrgCAAContact extends \Eloquent {
	protected $fillable = [];
	protected $table ="org_caa_contacts";
}