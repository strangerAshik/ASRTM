<?php

class LibSupportingDocumentType extends \Eloquent {
	protected $fillable = [];
	protected $table = 'lib_suporting_docs_type';
}