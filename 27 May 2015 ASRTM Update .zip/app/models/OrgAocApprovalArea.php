<?php

class OrgAocApprovalArea extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_aoc_approvals_areas';
}